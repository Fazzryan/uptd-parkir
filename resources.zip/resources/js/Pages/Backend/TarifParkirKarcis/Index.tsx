import React, { useState, useEffect, useRef } from "react";
import MainLayout from "@/Layouts/MainLayout";
import Card from "@/Components/UI/Card";
import Table from "@/Components/Data/Table";
import Button from "@/Components/UI/Button";
import TextInput from "@/Components/Form/TextInput";
import Pagination from "@/Components/Data/Pagination";
import ConfirmationModal from "@/Components/UI/ConfirmationModal";
import Modal from "@/Components/UI/Modal";
import { Head, useForm, usePage, router } from "@inertiajs/react";
import { Edit2, Trash2, Search, RotateCcw, Upload, Ticket } from "lucide-react";
import { PaginatedData, TarifParkirKarcis } from "@/types/model";
import axios from "axios";

interface IndexProps {
    tarif: PaginatedData<TarifParkirKarcis>;
    filters: {
        search?: string;
        per_page?: number | string;
    };
}

export default function Index({ tarif, filters }: IndexProps) {
    const auth = usePage<any>().props.auth || {};
    const permissions: string[] = auth.permissions || [];
    const roles: string[] = auth.roles || [];

    const canEdit =
        roles.includes("admin") ||
        roles.includes("user") ||
        permissions.length === 0 ||
        permissions.includes("edit-tarif-parkir");

    const canDelete =
        roles.includes("admin") ||
        roles.includes("user") ||
        permissions.length === 0 ||
        permissions.includes("delete-tarif-parkir");

    const [localTarif, setLocalTarif] =
        useState<PaginatedData<TarifParkirKarcis>>(tarif);
    const [search, setSearch] = useState(filters.search || "");
    const [perPage, setPerPage] = useState(filters.per_page || 10);

    useEffect(() => {
        setLocalTarif(tarif);
    }, [tarif]);

    // Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [selectedTarif, setSelectedTarif] =
        useState<TarifParkirKarcis | null>(null);

    // Image Preview State
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement | null>(null);

    // Confirmation Modal State
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [itemToDelete, setItemToDelete] = useState<TarifParkirKarcis | null>(
        null,
    );

    // Form Hook
    const { data, setData, post, processing, errors, reset, clearErrors } =
        useForm<{
            kategori_kendaraan: string;
            nominal_tarif: number | string;
            keterangan: string;
            foto: File | null;
            _method?: string;
        }>({
            kategori_kendaraan: "",
            nominal_tarif: "",
            keterangan: "",
            foto: null,
        });

    const [isLoading, setIsLoading] = useState(false);
    const isFirstRender = useRef(true);

    const formatRupiah = (amount: number) => {
        return new Intl.NumberFormat("id-ID", {
            style: "currency",
            currency: "IDR",
            minimumFractionDigits: 0,
        }).format(amount);
    };

    const fetchData = (url: string, params: any = {}) => {
        setIsLoading(true);
        axios
            .get(url, { params, headers: { Accept: "application/json" } })
            .then((res) => {
                setLocalTarif(res.data);
            })
            .catch((err) => console.error("Error fetching data:", err))
            .finally(() => setIsLoading(false));
    };

    // Search & Filter Debounce
    useEffect(() => {
        if (isFirstRender.current) {
            isFirstRender.current = false;
            return;
        }

        const timeout = setTimeout(() => {
            fetchData(route("be.tarif-parkir.index"), {
                search,
                per_page: perPage,
            });
        }, 300);
        return () => clearTimeout(timeout);
    }, [search, perPage]);

    // Handlers
    const openCreateModal = () => {
        setIsEditMode(false);
        setSelectedTarif(null);
        setPreviewUrl(null);
        reset();
        clearErrors();
        setIsModalOpen(true);
    };

    const openEditModal = (item: TarifParkirKarcis) => {
        setIsEditMode(true);
        setSelectedTarif(item);
        setData({
            kategori_kendaraan: item.kategori_kendaraan,
            nominal_tarif: item.nominal_tarif,
            keterangan: item.keterangan || "",
            foto: null,
        });
        setPreviewUrl(item.foto ? `/storage/${item.foto}` : null);
        clearErrors();
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setPreviewUrl(null);
        reset();
    };

    const openDeleteModal = (item: TarifParkirKarcis) => {
        setItemToDelete(item);
        setShowDeleteModal(true);
    };

    const handleDelete = () => {
        if (!itemToDelete) return;

        router.delete(route("be.tarif-parkir.destroy", itemToDelete.id), {
            onSuccess: () => {
                setShowDeleteModal(false);
                setItemToDelete(null);
            },
        });
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0] || null;
        if (file) {
            setData("foto", file);
            setPreviewUrl(URL.createObjectURL(file));
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isEditMode && selectedTarif) {
            router.post(
                route("be.tarif-parkir.update", selectedTarif.id),
                {
                    _method: "put",
                    kategori_kendaraan: data.kategori_kendaraan,
                    nominal_tarif: data.nominal_tarif,
                    keterangan: data.keterangan,
                    foto: data.foto,
                },
                {
                    onSuccess: () => closeModal(),
                },
            );
        } else {
            post(route("be.tarif-parkir.store"), {
                onSuccess: () => closeModal(),
            });
        }
    };

    const handleResetFilter = () => {
        setSearch("");
        setPerPage(10);
    };

    return (
        <>
            <Head title="Manajemen Tarif Parkir & Karcis" />

            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800 tracking-tight dark:text-slate-200">
                        Manajemen Tarif Parkir & Karcis
                    </h1>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                        Kelola data tarif retribusi dan contoh karcis resmi UPTD
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <Button
                        variant="primary"
                        onClick={openCreateModal}
                        className="shadow-lg shadow-brand-blue-100 dark:shadow-none"
                    >
                        <span>Tambah Tarif / Karcis</span>
                    </Button>
                </div>
            </div>

            <Card className="!overflow-visible relative z-30 dark:bg-slate-800 dark:border-slate-700 dark:shadow-slate-700/50">
                <div className="p-6 border-b border-slate-50 dark:border-slate-700 flex flex-col md:flex-row items-center gap-4 relative z-30 overflow-visible">
                    {/* Search Input */}
                    <div className="relative w-full md:w-80">
                        <TextInput
                            iconLeft={<Search size={18} />}
                            className="w-full font-medium dark:bg-slate-700 dark:text-slate-200 dark:border-slate-600"
                            containerClassName="relative w-full"
                            placeholder="Cari kategori / tarif..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>

                    {/* Reset Button */}
                    {search && (
                        <Button
                            variant="danger"
                            onClick={handleResetFilter}
                            className="flex items-center gap-2 whitespace-nowrap"
                        >
                            <RotateCcw size={16} />
                            <span>Reset</span>
                        </Button>
                    )}
                </div>

                {/* Tabel */}
                <Table
                    isLoading={isLoading}
                    columns={[
                        {
                            header: "#",
                            className:
                                "text-center text-sm font-medium text-slate-400 dark:text-slate-200 w-16",
                            headerClassName: "text-center w-16",
                            render: (_: TarifParkirKarcis, index: number) =>
                                (localTarif.current_page - 1) *
                                    localTarif.per_page +
                                index +
                                1,
                        },
                        {
                            header: "Foto Karcis",
                            className: "w-32 text-center",
                            headerClassName: "text-center w-32",
                            render: (item: TarifParkirKarcis) => (
                                <div className="flex items-center justify-center">
                                    {item.foto ? (
                                        <img
                                            src={`/storage/${item.foto}`}
                                            alt={item.kategori_kendaraan}
                                            className="h-14 w-14 object-cover rounded-xl border border-slate-200 shadow-sm dark:border-slate-700"
                                        />
                                    ) : (
                                        <div className="h-14 w-14 rounded-xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-400">
                                            <Ticket size={20} />
                                        </div>
                                    )}
                                </div>
                            ),
                        },
                        {
                            header: "Kategori Kendaraan",
                            className:
                                "text-slate-800 font-bold dark:text-slate-200",
                            render: (item: TarifParkirKarcis) =>
                                item.kategori_kendaraan,
                        },
                        {
                            header: "Nominal Tarif",
                            className: "w-44",
                            render: (item: TarifParkirKarcis) => (
                                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-extrabold bg-brand-blue-50 text-brand-blue-700 dark:bg-brand-blue-900/40 dark:text-brand-blue-300">
                                    {formatRupiah(item.nominal_tarif)}
                                </span>
                            ),
                        },
                        {
                            header: "Keterangan",
                            className:
                                "text-slate-600 dark:text-slate-300 text-sm",
                            render: (item: TarifParkirKarcis) =>
                                item.keterangan || "-",
                        },
                        {
                            header: "Aksi",
                            headerClassName: "text-center w-32",
                            className: "text-center",
                            render: (item: TarifParkirKarcis) => (
                                <div className="flex items-center justify-center gap-2">
                                    {canEdit && (
                                        <button
                                            onClick={() => openEditModal(item)}
                                            className="p-2.5 text-slate-400 hover:text-brand-blue-600 hover:bg-brand-blue-50 rounded-xl active:scale-90 transition-all cursor-pointer dark:hover:bg-slate-700 dark:hover:text-brand-blue-400"
                                        >
                                            <Edit2 size={16} />
                                        </button>
                                    )}
                                    {canDelete && (
                                        <button
                                            onClick={() =>
                                                openDeleteModal(item)
                                            }
                                            className="p-2.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl active:scale-90 transition-all cursor-pointer dark:hover:bg-slate-700 dark:hover:text-rose-400"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    )}
                                </div>
                            ),
                        },
                    ]}
                    data={localTarif.data}
                />

                {/* Pagination Section */}
                <div className="p-6 border-t border-slate-50 dark:border-slate-700 flex flex-col md:flex-row items-center justify-between gap-6 bg-slate-50/20 dark:bg-slate-700/20">
                    {/* Kiri: Info Data */}
                    <p className="text-sm text-slate-500 dark:text-slate-200">
                        Menampilkan{" "}
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                            {localTarif.from ?? 0}
                        </span>{" "}
                        sampai{" "}
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                            {localTarif.to ?? 0}
                        </span>{" "}
                        dari{" "}
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                            {localTarif.total}
                        </span>{" "}
                        data
                    </p>

                    {/* Tengah: Per Page Selector */}
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                        <span>Tampilkan</span>
                        <select
                            value={perPage}
                            onChange={(e) =>
                                setPerPage(parseInt(e.target.value))
                            }
                            className="bg-white border border-slate-200 text-slate-700 text-sm rounded-xl focus:ring-3 focus:ring-brand-green-500/10 focus:border-brand-green-500 block py-1.5 px-3 transition-all outline-none cursor-pointer dark:bg-slate-700 dark:text-slate-200 dark:border-slate-600"
                        >
                            <option value="5">5</option>
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>

                    {/* Kanan: Pagination */}
                    <Pagination
                        links={localTarif.links}
                        onPageChange={(url) => fetchData(url)}
                    />
                </div>
            </Card>

            {/* Modal Form */}
            <Modal
                show={isModalOpen}
                onClose={closeModal}
                title={
                    isEditMode ? "Edit Tarif & Karcis" : "Tambah Tarif & Karcis"
                }
                maxWidth="xl"
                footer={
                    <>
                        <Button
                            variant="secondary"
                            onClick={closeModal}
                            disabled={processing}
                        >
                            Batal
                        </Button>
                        <Button
                            variant="primary"
                            onClick={handleSubmit}
                            disabled={processing}
                        >
                            {processing ? "Menyimpan..." : "Simpan"}
                        </Button>
                    </>
                }
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                            Kategori Kendaraan
                        </label>
                        <TextInput
                            type="text"
                            placeholder="Contoh: Sepeda Motor (Roda 2)"
                            value={data.kategori_kendaraan}
                            onChange={(e) =>
                                setData("kategori_kendaraan", e.target.value)
                            }
                            className="w-full text-sm"
                            error={errors.kategori_kendaraan}
                        />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                                Nominal Tarif (Rp)
                            </label>
                            <TextInput
                                type="number"
                                placeholder="Contoh: 2000"
                                value={data.nominal_tarif}
                                onChange={(e) =>
                                    setData("nominal_tarif", e.target.value)
                                }
                                className="w-full text-sm"
                                error={errors.nominal_tarif}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                                Keterangan / Satuan
                            </label>
                            <TextInput
                                type="text"
                                placeholder="Contoh: / sekali parkir"
                                value={data.keterangan}
                                onChange={(e) =>
                                    setData("keterangan", e.target.value)
                                }
                                className="w-full text-sm"
                                error={errors.keterangan}
                            />
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                            Foto Karcis Resmi
                        </label>
                        <div className="flex items-center gap-4">
                            {previewUrl ? (
                                <img
                                    src={previewUrl}
                                    alt="Preview Karcis"
                                    className="h-20 w-20 object-cover rounded-xl border border-slate-200 shadow-sm dark:border-slate-700"
                                />
                            ) : (
                                <div className="h-20 w-20 rounded-xl bg-slate-100 dark:bg-slate-700 flex flex-col items-center justify-center text-slate-400 border border-dashed border-slate-300 dark:border-slate-600">
                                    <Ticket size={24} />
                                    <span className="text-[10px] mt-1">
                                        Preview
                                    </span>
                                </div>
                            )}

                            <div className="flex-1">
                                <input
                                    type="file"
                                    ref={fileInputRef}
                                    onChange={handleFileChange}
                                    accept="image/jpeg,image/png,image/jpg,image/webp"
                                    className="hidden"
                                />
                                <Button
                                    type="button"
                                    variant="secondary"
                                    onClick={() =>
                                        fileInputRef.current?.click()
                                    }
                                    className="flex items-center gap-2"
                                >
                                    <Upload size={16} />
                                    <span>Pilih Foto Karcis</span>
                                </Button>
                                <p className="text-xs text-slate-400 mt-1">
                                    Format: JPG, PNG, WEBP. Maks: 2MB.
                                </p>
                            </div>
                        </div>
                        {errors.foto && (
                            <p className="text-xs text-rose-500 mt-1">
                                {errors.foto}
                            </p>
                        )}
                    </div>
                </form>
            </Modal>

            {/* Modal Konfirmasi Hapus */}
            <ConfirmationModal
                show={showDeleteModal}
                processing={processing}
                title="Hapus Tarif & Karcis"
                message={`Apakah Anda yakin ingin menghapus data tarif "${itemToDelete?.kategori_kendaraan}"? Tindakan ini tidak dapat dibatalkan.`}
                onConfirm={handleDelete}
                onCancel={() => setShowDeleteModal(false)}
            />
        </>
    );
}

Index.layout = (page: React.ReactNode) => <MainLayout>{page}</MainLayout>;

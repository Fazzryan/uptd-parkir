import React, { useState, useEffect, useRef } from "react";
import MainLayout from "@/Layouts/MainLayout";
import Card from "@/Components/UI/Card";
import Table from "@/Components/Data/Table";
import Button from "@/Components/UI/Button";
import TextInput from "@/Components/Form/TextInput";
import Pagination from "@/Components/Data/Pagination";
import ConfirmationModal from "@/Components/UI/ConfirmationModal";
import Modal from "@/Components/UI/Modal";
import SelectSearch from "@/Components/Form/SelectSearch";
import { Head, useForm, usePage, router } from "@inertiajs/react";
import {
    Edit2,
    Trash2,
    Search,
    MapPin,
    RotateCcw,
    ExternalLink,
} from "lucide-react";
import { PaginatedData, WilayahParkir, Kecamatan } from "@/types/model";
import axios from "axios";

interface IndexProps {
    wilayah: PaginatedData<WilayahParkir>;
    kecamatanList: Kecamatan[];
    filters: {
        search?: string;
        kecamatan_id?: number | string;
        per_page?: number | string;
    };
}

export default function Index({ wilayah, kecamatanList = [], filters }: IndexProps) {
    const auth = usePage<any>().props.auth || {};
    const permissions: string[] = auth.permissions || [];
    const roles: string[] = auth.roles || [];

    const canEdit =
        roles.includes("admin") ||
        roles.includes("user") ||
        permissions.length === 0 ||
        permissions.includes("edit-wilayah-parkir");

    const canDelete =
        roles.includes("admin") ||
        roles.includes("user") ||
        permissions.length === 0 ||
        permissions.includes("delete-wilayah-parkir");

    const [localWilayah, setLocalWilayah] = useState<PaginatedData<WilayahParkir>>(wilayah);
    const [search, setSearch] = useState(filters.search || "");
    const [selectedKecamatanId, setSelectedKecamatanId] = useState<number | string>(filters.kecamatan_id || "");
    const [perPage, setPerPage] = useState(filters.per_page || 10);

    useEffect(() => {
        setLocalWilayah(wilayah);
    }, [wilayah]);

    // Opsi untuk SelectSearch Kecamatan
    const kecamatanOptions = kecamatanList.map((k) => ({
        value: String(k.id),
        label: k.nama_kecamatan,
    }));

    // Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isEditMode, setIsEditMode] = useState(false);
    const [selectedWilayah, setSelectedWilayah] = useState<WilayahParkir | null>(null);

    // Confirmation Modal State
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [itemToDelete, setItemToDelete] = useState<WilayahParkir | null>(null);

    // Form Hook
    const {
        data,
        setData,
        post,
        put,
        processing,
        errors,
        reset,
        clearErrors,
    } = useForm({
        kecamatan_id: "" as number | string,
        nama_jalan: "",
        latitude: "",
        longitude: "",
    });

    const [isLoading, setIsLoading] = useState(false);
    const isFirstRender = useRef(true);

    const fetchData = (url: string, params: any = {}) => {
        setIsLoading(true);
        axios
            .get(url, { params, headers: { Accept: "application/json" } })
            .then((res) => {
                setLocalWilayah(res.data);
            })
            .catch((err) => console.error("Error fetching data:", err))
            .finally(() => setIsLoading(false));
    };

    // Search & Filter Debounce
    useEffect(() => {
        if (isFirstRender.current) {
            isFirstRender.current = false;
            return;
        }

        const timeout = setTimeout(() => {
            fetchData(route("be.wilayah-parkir.index"), {
                search,
                kecamatan_id: selectedKecamatanId,
                per_page: perPage,
            });
        }, 300);
        return () => clearTimeout(timeout);
    }, [search, selectedKecamatanId, perPage]);

    // Handlers
    const openCreateModal = () => {
        setIsEditMode(false);
        setSelectedWilayah(null);
        reset();
        clearErrors();
        setIsModalOpen(true);
    };

    const openEditModal = (item: WilayahParkir) => {
        setIsEditMode(true);
        setSelectedWilayah(item);
        setData({
            kecamatan_id: item.kecamatan_id ? String(item.kecamatan_id) : "",
            nama_jalan: item.nama_jalan,
            latitude: item.latitude,
            longitude: item.longitude,
        });
        clearErrors();
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        reset();
    };

    const openDeleteModal = (item: WilayahParkir) => {
        setItemToDelete(item);
        setShowDeleteModal(true);
    };

    const handleDelete = () => {
        if (!itemToDelete) return;

        router.delete(route("be.wilayah-parkir.destroy", itemToDelete.id), {
            onSuccess: () => {
                setShowDeleteModal(false);
                setItemToDelete(null);
            },
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isEditMode && selectedWilayah) {
            put(route("be.wilayah-parkir.update", selectedWilayah.id), {
                onSuccess: () => closeModal(),
            });
        } else {
            post(route("be.wilayah-parkir.store"), {
                onSuccess: () => closeModal(),
            });
        }
    };

    const handleResetFilter = () => {
        setSearch("");
        setSelectedKecamatanId("");
        setPerPage(10);
    };

    return (
        <>
            <Head title="Manajemen Wilayah Parkir" />

            {/* Header Section */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                <div>
                    <h1 className="text-2xl font-bold text-slate-800 tracking-tight dark:text-slate-200">
                        Manajemen Wilayah Parkir
                    </h1>
                    <p className="text-sm text-slate-500 dark:text-slate-400">
                        Kelola data titik lokasi dan titik koordinat parkir Kabupaten Tasikmalaya
                    </p>
                </div>
                <div className="flex items-center gap-3">
                    <Button
                        variant="primary"
                        onClick={openCreateModal}
                        className="shadow-lg shadow-indigo-100 dark:shadow-none"
                    >
                        <span>Tambah Wilayah Parkir</span>
                    </Button>
                </div>
            </div>

            <Card className="!overflow-visible relative z-30 dark:bg-slate-800 dark:border-slate-700 dark:shadow-slate-700/50">
                <div className="p-6 border-b border-slate-50 dark:border-slate-700 flex flex-col md:flex-row items-center gap-4 relative z-30 overflow-visible">
                    {/* Search Input */}
                    <div className="relative w-full md:w-80">
                        <TextInput
                            iconLeft={<Search size={18} />}
                            className="w-full font-medium dark:bg-slate-700 dark:text-slate-200 dark:border-slate-600"
                            containerClassName="relative w-full"
                            placeholder="Cari lokasi jalan..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>

                    {/* Filter Kecamatan */}
                    <div className="w-full md:w-64 relative z-30">
                        <SelectSearch
                            options={kecamatanOptions}
                            value={String(selectedKecamatanId)}
                            onChange={(val) => setSelectedKecamatanId(val)}
                            placeholder="Filter Kecamatan..."
                            isSearchable
                        />
                    </div>

                    {/* Reset Button */}
                    {(search || selectedKecamatanId) && (
                        <Button
                            variant="danger"
                            onClick={handleResetFilter}
                            className="flex items-center gap-2 whitespace-nowrap"
                        >
                            <RotateCcw size={16} />
                            <span>Reset</span>
                        </Button>
                    )}
                </div>

                {/* Tabel */}
                <Table
                    isLoading={isLoading}
                    columns={[
                        {
                            header: "#",
                            className:
                                "text-center text-sm font-medium text-slate-400 dark:text-slate-200 w-16",
                            headerClassName: "text-center w-16",
                            render: (_: WilayahParkir, index: number) =>
                                (localWilayah.current_page - 1) * localWilayah.per_page +
                                index +
                                1,
                        },
                        {
                            header: "Kecamatan",
                            className:
                                "text-slate-800 font-bold dark:text-slate-200 w-48",
                            render: (item: WilayahParkir) =>
                                item.kecamatan?.nama_kecamatan || "-",
                        },
                        {
                            header: "Nama Jalan / Titik Lokasi",
                            className:
                                "text-slate-700 dark:text-slate-300 font-medium",
                            render: (item: WilayahParkir) => item.nama_jalan,
                        },
                        {
                            header: "Koordinat (Lat, Long)",
                            className: "w-56 text-slate-500 text-xs font-mono dark:text-slate-400",
                            render: (item: WilayahParkir) => (
                                <div className="flex items-center gap-2">
                                    <MapPin size={14} className="text-indigo-500 shrink-0" />
                                    <span>
                                        {item.latitude}, {item.longitude}
                                    </span>
                                    {item.latitude && item.longitude && (
                                        <a
                                            href={`https://www.google.com/maps?q=${item.latitude},${item.longitude}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 ml-1"
                                            title="Buka di Google Maps"
                                        >
                                            <ExternalLink size={14} />
                                        </a>
                                    )}
                                </div>
                            ),
                        },
                        {
                            header: "Aksi",
                            headerClassName: "text-center w-32",
                            className: "text-center",
                            render: (item: WilayahParkir) => (
                                <div className="flex items-center justify-center gap-2">
                                    {canEdit && (
                                        <button
                                            onClick={() => openEditModal(item)}
                                            className="p-2.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl active:scale-90 transition-all cursor-pointer dark:hover:bg-slate-700 dark:hover:text-indigo-400"
                                        >
                                            <Edit2 size={16} />
                                        </button>
                                    )}
                                    {canDelete && (
                                        <button
                                            onClick={() => openDeleteModal(item)}
                                            className="p-2.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl active:scale-90 transition-all cursor-pointer dark:hover:bg-slate-700 dark:hover:text-rose-400"
                                        >
                                            <Trash2 size={16} />
                                        </button>
                                    )}
                                </div>
                            ),
                        },
                    ]}
                    data={localWilayah.data}
                />

                {/* Pagination Section */}
                <div className="p-6 border-t border-slate-50 dark:border-slate-700 flex flex-col md:flex-row items-center justify-between gap-6 bg-slate-50/20 dark:bg-slate-700/20">
                    {/* Kiri: Info Data */}
                    <p className="text-sm text-slate-500 dark:text-slate-200">
                        Menampilkan{" "}
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                            {localWilayah.from ?? 0}
                        </span>{" "}
                        sampai{" "}
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                            {localWilayah.to ?? 0}
                        </span>{" "}
                        dari{" "}
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                            {localWilayah.total}
                        </span>{" "}
                        data
                    </p>

                    {/* Tengah: Per Page Selector */}
                    <div className="flex items-center gap-3 text-sm text-slate-400">
                        <span>Tampilkan</span>
                        <select
                            value={perPage}
                            onChange={(e) => setPerPage(parseInt(e.target.value))}
                            className="bg-white border border-slate-200 text-slate-700 text-sm rounded-xl focus:ring-3 focus:ring-brand-green-500/10 focus:border-brand-green-500 block py-1.5 px-3 transition-all outline-none cursor-pointer dark:bg-slate-700 dark:text-slate-200 dark:border-slate-600"
                        >
                            <option value="5">5</option>
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>

                    {/* Kanan: Pagination */}
                    <Pagination
                        links={localWilayah.links}
                        onPageChange={(url) => fetchData(url)}
                    />
                </div>
            </Card>

            {/* Modal Form */}
            <Modal
                show={isModalOpen}
                onClose={closeModal}
                title={isEditMode ? "Edit Wilayah Parkir" : "Tambah Wilayah Parkir"}
                maxWidth="xl"
                footer={
                    <>
                        <Button
                            variant="secondary"
                            onClick={closeModal}
                            disabled={processing}
                        >
                            Batal
                        </Button>
                        <Button
                            variant="primary"
                            onClick={handleSubmit}
                            disabled={processing}
                        >
                            {processing ? "Menyimpan..." : "Simpan"}
                        </Button>
                    </>
                }
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                            Kecamatan
                        </label>
                        <SelectSearch
                            options={kecamatanOptions}
                            value={String(data.kecamatan_id)}
                            onChange={(val) => setData("kecamatan_id", val)}
                            placeholder="Pilih Kecamatan..."
                            isSearchable
                        />
                        {errors.kecamatan_id && (
                            <p className="text-xs text-rose-500 mt-1">{errors.kecamatan_id}</p>
                        )}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                            Nama Jalan / Titik Lokasi
                        </label>
                        <TextInput
                            type="text"
                            placeholder="Contoh: Jl. Raya Singaparna No. 45"
                            value={data.nama_jalan}
                            onChange={(e) => setData("nama_jalan", e.target.value)}
                            className="w-full text-sm"
                            error={errors.nama_jalan}
                        />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                                Latitude
                            </label>
                            <TextInput
                                type="text"
                                placeholder="Contoh: -7.352400"
                                value={data.latitude}
                                onChange={(e) => setData("latitude", e.target.value)}
                                className="w-full text-sm"
                                error={errors.latitude}
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1 dark:text-slate-300">
                                Longitude
                            </label>
                            <TextInput
                                type="text"
                                placeholder="Contoh: 108.112300"
                                value={data.longitude}
                                onChange={(e) => setData("longitude", e.target.value)}
                                className="w-full text-sm"
                                error={errors.longitude}
                            />
                        </div>
                    </div>
                </form>
            </Modal>

            {/* Modal Konfirmasi Hapus */}
            <ConfirmationModal
                show={showDeleteModal}
                processing={processing}
                title="Hapus Wilayah Parkir"
                message={`Apakah Anda yakin ingin menghapus wilayah parkir "${itemToDelete?.nama_jalan}"? Tindakan ini tidak dapat dibatalkan.`}
                onConfirm={handleDelete}
                onCancel={() => setShowDeleteModal(false)}
            />
        </>
    );
}

Index.layout = (page: React.ReactNode) => <MainLayout>{page}</MainLayout>;
